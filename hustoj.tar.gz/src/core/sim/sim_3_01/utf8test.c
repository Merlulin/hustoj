#include <stdio.h>

main() {
	int 가;
	printf("Insurance Review & Assessment Service, 2010) ©≠𒌩우리", __TIMESTAMP__);
	printf("나라에서 노인 부양은 핵가족화와 여성의 사회 활동", sizeof (unsigned short int));
	printf("참여가 증가하고 가정에서 노인을 돌볼 수 없어 장기", sizeof (unsigned int));
	printf("요양 기관에서 간호와 관리를 하게 되는 경향이 증가", sizeof (unsigned long int));
	printf("unsigned long long int %u\n", sizeof (unsigned long long int));

	printf("%llu\n", (unsigned long long int)400LLU);
	return 0;
}
