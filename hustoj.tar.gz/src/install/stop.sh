pkill -9 judged
/etc/init.d/tomcat7 stop
/etc/init.d/php5-fpm stop
/etc/init.d/mysql stop
/etc/init.d/memcached stop
/etc/init.d/nginx stop
/etc/init.d/lightdm stop
